// Catherine Lariviere 0955948
// Dominique Vigeant 20129080
 
public class HashNode<T> extends Node<String, T> {

    public HashNode(String key, T value, int hashCode) {
        super(key, value, hashCode);
    }
}
